package ColaBatalla;

import tropas.Tropa;

/**
 * Implementación simple de una cola para tropas. No lanza Exception genérica,
 * devuelve null si está vacía.
 *
 * @author lucas
 */
public class Cola {

    private Nodo frente;
    private Nodo ultimo;

    public Cola() {
        this.frente = null;
        this.ultimo = null;
    }

    // Encolar un nuevo elemento
    public void encolar(Tropa dato) {
        Nodo nuevo = new Nodo(dato);
        if (ultimo != null) {
            ultimo.setSiguiente(nuevo);
        }
        ultimo = nuevo;
        if (frente == null) {
            frente = nuevo;
        }
    }

    // Desencolar: devuelve el frente o null si está vacía
    public Tropa desencolar() {
        if (frente == null) {
            return null; // ya no lanza Exception
        }
        Tropa dato = frente.getDato();
        frente = frente.getSiguiente();
        if (frente == null) {
            ultimo = null;
        }
        return dato;
    }

    // Ver el frente sin desencolar
    public Tropa frente() {
        if (frente == null) {
            return null; // ya no lanza Exception
        }
        return frente.getDato();
    }

    // Verificar si está vacía
    public boolean estaVacia() {
        return frente == null;
    }
}
