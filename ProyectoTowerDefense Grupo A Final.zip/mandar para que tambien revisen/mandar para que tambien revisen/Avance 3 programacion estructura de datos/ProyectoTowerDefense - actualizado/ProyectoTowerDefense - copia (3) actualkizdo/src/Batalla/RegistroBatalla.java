package batalla;

public class RegistroBatalla {

    private static class NodoRonda {

        int ronda;
        String[] eventos;
        int cantidad;
        NodoRonda izquierda;
        NodoRonda derecha;

        NodoRonda(int ronda) {
            this.ronda = ronda;
            this.eventos = new String[4]; // capacidad inicial
            this.cantidad = 0;
        }

        void agregarEvento(String evento) {
            if (cantidad == eventos.length) {
                // redimensiona el arreglo de eventos
                String[] nuevo = new String[eventos.length * 2];
                for (int i = 0; i < eventos.length; i++) {
                    nuevo[i] = eventos[i];
                }
                eventos = nuevo;
            }
            eventos[cantidad++] = evento;
        }

        String[] obtenerEventos() {
            String[] res = new String[cantidad];
            for (int i = 0; i < cantidad; i++) {
                res[i] = eventos[i];
            }
            return res;
        }
    }

    private NodoRonda raiz;

    public void registrarEvento(int ronda, String evento) {
        raiz = insertar(raiz, ronda, evento);
    }

    private NodoRonda insertar(NodoRonda nodo, int ronda, String evento) {
        if (nodo == null) {
            nodo = new NodoRonda(ronda);
            nodo.agregarEvento(evento);
            return nodo;
        }
        if (ronda < nodo.ronda) {
            nodo.izquierda = insertar(nodo.izquierda, ronda, evento);
        } else if (ronda > nodo.ronda) {
            nodo.derecha = insertar(nodo.derecha, ronda, evento);
        } else {
            nodo.agregarEvento(evento);
        }
        return nodo;
    }

    public String[] obtenerEventosDeRonda(int ronda) {
        NodoRonda nodo = buscar(raiz, ronda);
        return nodo == null ? new String[0] : nodo.obtenerEventos();
    }

    private NodoRonda buscar(NodoRonda nodo, int ronda) {
        if (nodo == null) {
            return null;
        }
        if (ronda == nodo.ronda) {
            return nodo;
        }
        if (ronda < nodo.ronda) {
            return buscar(nodo.izquierda, ronda);
        }
        return buscar(nodo.derecha, ronda);
    }

    public int[] obtenerRondasRegistradas() {
        int total = contarNodos(raiz);
        int[] rondas = new int[total];
        llenarRondas(raiz, rondas, new int[]{0});
        return rondas;
    }

    private int contarNodos(NodoRonda nodo) {
        if (nodo == null) {
            return 0;
        }
        return 1 + contarNodos(nodo.izquierda) + contarNodos(nodo.derecha);
    }

    private void llenarRondas(NodoRonda nodo, int[] arr, int[] idx) {
        if (nodo == null) {
            return;
        }
        llenarRondas(nodo.izquierda, arr, idx);
        arr[idx[0]++] = nodo.ronda;
        llenarRondas(nodo.derecha, arr, idx);
    }

    public String[] obtenerHistorialCompleto() {
        int total = contarEventos(raiz);
        String[] historial = new String[total];
        llenarHistorial(raiz, historial, new int[]{0});
        return historial;
    }

    private int contarEventos(NodoRonda nodo) {
        if (nodo == null) {
            return 0;
        }
        return 1 + nodo.cantidad + contarEventos(nodo.izquierda) + contarEventos(nodo.derecha);
    }

    private void llenarHistorial(NodoRonda nodo, String[] arr, int[] idx) {
        if (nodo == null) {
            return;
        }
        llenarHistorial(nodo.izquierda, arr, idx);
        arr[idx[0]++] = "— Ronda " + nodo.ronda + " —";
        String[] evs = nodo.obtenerEventos();
        for (int i = 0; i < evs.length; i++) {
            arr[idx[0]++] = evs[i];
        }
        llenarHistorial(nodo.derecha, arr, idx);
    }
}
