package Invasion;

public class claseControladora {

    private static ListaEnlazadaResultados listaResultados = new ListaEnlazadaResultados();//toma la lista, entre otras cosas, como nodos, listas, etc.
    private static String nombreJugador;

    public static String getNombreJugador() {
        return nombreJugador;
    }

    public static void setNombreJugador(String nombreJugador) {
        claseControladora.nombreJugador = nombreJugador;
    }

    public static void registrarResultado(Invasion.ResultadoBatalla resultado) {
        listaResultados.agregar(resultado);
    }

    public static int getCantidadBatallas() {
        return listaResultados.contarBatallas();
    }

    public static int getVictorias() {
        return listaResultados.contarVictorias();
    }

    public static boolean esEmperador() {
        return listaResultados.esEmperador();
    }

    public static NodoResultado getCabeza() {
        return listaResultados.getCabeza();
    }

    public static void reiniciar() {
        listaResultados.limpiar();
    }
}
