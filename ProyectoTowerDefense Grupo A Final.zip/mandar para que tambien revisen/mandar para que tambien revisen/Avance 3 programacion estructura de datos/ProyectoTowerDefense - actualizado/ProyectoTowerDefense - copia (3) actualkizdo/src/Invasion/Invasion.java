package Invasion;

import batalla.Batalla;
import batalla.RegistroBatalla;
import jugadores.Player;
import jugadores.CPU;
import tropas.Tropa;

public class Invasion {

    private final Player jugador;
    private final CPU cpu;
    private final Batalla batalla;
    private boolean terminada;
    private ResultadoBatalla resultadoFinal;

    public Invasion(Player jugador, CPU cpu) {
        this.jugador = jugador;
        this.cpu = cpu;
        this.batalla = new Batalla(jugador, cpu);
        this.terminada = false;
        this.resultadoFinal = null;

    }

    // Acciones de preparación
    public void asignarTropaJugador(int camino, Tropa tropa) {
        batalla.prepararJugador(camino, tropa);
    }

    public void prepararCPU() {
        batalla.prepararCPU();
    }

    //se agrego un metodo que tome el resultado de la batalla
    private void determinarResultado() {

        ResultadoBatalla resultado = batalla.resultadoBatalla();

        if (resultado != null) {
            resultadoFinal = resultado;
        }
    }

    // Un enfrentamiento (resuelve ambos caminos una vez)
    public void ejecutarTurno() {
        try {
            batalla.Enfrentamiento();
        } catch (Exception e) {
            // Evita romper el flujo en la GUI
        }
        if (batalla.batallaTerminada()) {
            terminada = true;
            determinarResultado();
        }
    }

    // Ejecuta la ronda completa hasta vaciar ambos caminos o terminar la batalla
    public void ejecutarTurnoCompleto() {
        try {
            while (!batalla.rondaTerminada() && !batalla.batallaTerminada()) {
                batalla.Enfrentamiento();
            }
        } catch (Exception e) {
            // Evita romper el flujo en la GUI
        }
        if (batalla.batallaTerminada()) {
            determinarResultado();
            terminada = true;

        }
    }

    // Registro (árbol binario por rondas)
    public RegistroBatalla getRegistro() {
        return batalla.getRegistro();
    }

    // Avanza la ronda si terminó y devuelve cuál terminó
    public Integer siguienteRondaSiTermino() {
        if (batalla.rondaTerminada() && !batalla.batallaTerminada()) {
            int rondaTerminada = batalla.getRonda();
            batalla.AumentarRonda();
            return rondaTerminada;
        }
        return null;
    }

    // Estado global de la invasión
    public String estadoInvasion() {
        if (terminada) {
            return "Resultado: " + batalla.resultadoBatalla();
        }
        return "En curso - Ronda " + batalla.getRonda();
    }

    public boolean invasionTerminada() {
        return terminada;
    }

    // Exponer batalla actual para la vista (FrmBatalla)
    public Batalla obtenerBatallaActual() {
        return batalla;
    }

    public enum ResultadoBatalla {
        VICTORIA,
        DERROTA
    }

    // Getters básicos
    public Player getJugador() {
        return jugador;
    }

    public CPU getCpu() {
        return cpu;
    }

    public ResultadoBatalla getResultadoFinal() {
        return resultadoFinal;
    }

    public void setResultadoFinal(ResultadoBatalla resultadoFinal) {
        this.resultadoFinal = resultadoFinal;
    }

}
