package Formularios;

import Invasion.claseControladora;
import Invasion.NodoResultado;
import Invasion.Invasion;

import javax.swing.*;
import java.awt.*;

public class FrmMostrarInvasion extends JFrame {

    private String nombreJugador;
    private String[] ronda1 = new String[8];
    private String[] ronda2 = new String[4];
    private String[] ronda3 = new String[2];
    private String ganadorFinal;

    private final Color colorGris = new Color(200, 200, 200);
    private final Color colorVerde = new Color(62, 179, 64);
    private final Color colorRojo = new Color(220, 60, 60);
    private final Color colorDorado = new Color(255, 215, 0);
    private final Font fuenteCasilla = new Font("Tw Cen MT", Font.BOLD, 14);

    public FrmMostrarInvasion() {
        nombreJugador = "Jugador";

        setTitle("Torneo de Invasión");
        setSize(640, 640);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        JLabel fondo = new JLabel(new ImageIcon(getClass().getResource("/imagenes/newnewFrmInvasion.png")));
        fondo.setBounds(0, 0, 640, 640);
        fondo.setLayout(null);
        add(fondo);

        prepararParticipantes();
        actualizarResultados();

        PanelTorneo panelVisual = new PanelTorneo();
        panelVisual.setOpaque(false);
        panelVisual.setBounds(0, 0, 640, 640);
        fondo.add(panelVisual);

        // Botón inferior según estado
        int baseX = 250;
        int baseY = 520;
        int anchoCasilla = 140;
        int altoCasilla = 36;

        if (ganadorFinal == null) {
            JButton botonContinuar = new JButton("Continuar");
            botonContinuar.setBounds(baseX, baseY + altoCasilla + 10, anchoCasilla, 30);
            botonContinuar.setBackground(new Color(0, 153, 153));
            botonContinuar.setForeground(Color.WHITE);
            botonContinuar.setFont(fuenteCasilla);
            fondo.add(botonContinuar);

            botonContinuar.addActionListener(e -> {
                if (claseControladora.getCantidadBatallas() < 3) {
                    FrmBatalla nuevaBatalla = new FrmBatalla(claseControladora.getNombreJugador());
                    nuevaBatalla.setVisible(true);
                    dispose();
                }
            });
        } else {
            JButton botonVolverMenu = new JButton("Volver al menú");
            botonVolverMenu.setBounds(baseX, baseY + altoCasilla + 10, anchoCasilla, 30);
            botonVolverMenu.setBackground(new Color(80, 80, 80));
            botonVolverMenu.setForeground(Color.WHITE);
            botonVolverMenu.setFont(fuenteCasilla);
            fondo.add(botonVolverMenu);

            botonVolverMenu.addActionListener(e -> {
                FrmInvasion inicio = new FrmInvasion(claseControladora.getNombreJugador());
                inicio.setVisible(true);
                dispose();
            });
        }
    }

    private void prepararParticipantes() {
        ronda1[0] = nombreJugador;
        ronda1[1] = "CPU 1";
        ronda1[2] = "CPU 2";
        ronda1[3] = "CPU 3";
        ronda1[4] = "CPU 4";
        ronda1[5] = "CPU 5";
        ronda1[6] = "CPU 6";
        ronda1[7] = "CPU 7";
    }

    private void actualizarResultados() {
        NodoResultado nodoActual = claseControladora.getCabeza();
        Invasion.ResultadoBatalla[] resultados = new Invasion.ResultadoBatalla[3];
        int pos = 0;
        while (nodoActual != null && pos < 3) {
            resultados[pos] = nodoActual.getResultado();
            nodoActual = nodoActual.getSiguiente();
            pos++;
        }

        // Ronda 1
        if (resultados[0] != null) {
            ronda2[0] = (resultados[0] == Invasion.ResultadoBatalla.VICTORIA) ? nombreJugador : "CPU 1";
        }

        ronda2[1] = (Math.random() < 0.5) ? "CPU 2" : "CPU 3";

        ronda2[2] = (Math.random() < 0.5) ? "CPU 4" : "CPU 5";

        ronda2[3] = (Math.random() < 0.5) ? "CPU 6" : "CPU 7";

        // Ronda 2
        if (resultados[1] != null && ronda2[0] != null && ronda2[1] != null) {
            ronda3[0] = (resultados[1] == Invasion.ResultadoBatalla.VICTORIA) ? ronda2[0] : ronda2[1];

            ronda3[1] = (Math.random() < 0.5) ? ronda2[2] : ronda2[3];
        } else {
            ronda3[0] = null;
            ronda3[1] = null;
        }
        // Final
        if (resultados[2] != null && ronda3[0] != null && ronda3[1] != null) {
            ganadorFinal = (resultados[2] == Invasion.ResultadoBatalla.VICTORIA) ? ronda3[0] : ronda3[1];
        } else {
            ganadorFinal = null;
        }
    }

    private class PanelTorneo extends JPanel {

        private final int[][] posicionesRonda1 = {
            {50, 90}, {50, 140}, {50, 190}, {50, 240},
            {50, 290}, {50, 340}, {50, 390}, {50, 440}
        };
        private final int[][] posicionesRonda2 = {
            {250, 115}, {250, 215}, {250, 315}, {250, 415}
        };
        private final int[][] posicionesRonda3 = {
            {450, 165}, {450, 365}
        };
        private final int[] posicionFinal = {250, 520};

        private final int anchoCasilla = 140;
        private final int altoCasilla = 36;

        @Override
        protected void paintComponent(Graphics lienzo) {
            super.paintComponent(lienzo);
            // Mostrar encabezado de ronda
            int rondaActual = claseControladora.getCantidadBatallas();
            String textoEncabezado = "RONDA " + rondaActual + "/3 TERMINADA";
            String textoSubtitulo = "RESULTADOS:";

            lienzo.setColor(Color.BLACK);
            lienzo.setFont(new Font("Tw Cen MT", Font.BOLD, 24));
            FontMetrics fm = lienzo.getFontMetrics();
            int xEncabezado = (getWidth() - fm.stringWidth(textoEncabezado)) / 2;
            lienzo.drawString(textoEncabezado, xEncabezado, 40);

            lienzo.setFont(new Font("Tw Cen MT", Font.PLAIN, 18));
            fm = lienzo.getFontMetrics();
            int xSubtitulo = (getWidth() - fm.stringWidth(textoSubtitulo)) / 2;
            lienzo.drawString(textoSubtitulo, xSubtitulo, 65);

            // Ronda 1
            NodoResultado r1Nodo = claseControladora.getCabeza();
            Invasion.ResultadoBatalla resR1 = (r1Nodo != null) ? r1Nodo.getResultado() : null;

            for (int i = 0; i < 8; i++) {
                String textoCasilla = ronda1[i];
                Color color = colorGris;

                if (i == 0 || i == 1) {
                    if (resR1 != null) {
                        boolean victoriaJugador = resR1 == Invasion.ResultadoBatalla.VICTORIA;
                        color = (i == 0) ? (victoriaJugador ? colorVerde : colorRojo)
                                : (victoriaJugador ? colorRojo : colorVerde);
                    }
                } else if (i == 2 || i == 3) {
                    color = ronda2[1].equals(ronda1[i]) ? colorVerde : colorRojo;
                } else if (i == 4 || i == 5) {
                    color = ronda2[2].equals(ronda1[i]) ? colorVerde : colorRojo;
                } else if (i == 6 || i == 7) {
                    color = ronda2[3].equals(ronda1[i]) ? colorVerde : colorRojo;
                }

                dibujarCasilla(lienzo, posicionesRonda1[i][0], posicionesRonda1[i][1], textoCasilla, color);
            }

            // Ronda 2
            NodoResultado r2Nodo = (r1Nodo != null) ? r1Nodo.getSiguiente() : null;
            Invasion.ResultadoBatalla resR2 = (r2Nodo != null) ? r2Nodo.getResultado() : null;

            for (int i = 0; i < 4; i++) {
                String textoCasilla = (ronda2[i] != null) ? ronda2[i] : "–";
                Color color = colorGris;

                if (resR2 != null) {
                    if (i == 0 || i == 1) {
                        boolean victoriaJugadorEnR2 = resR2 == Invasion.ResultadoBatalla.VICTORIA;
                        boolean casillaEsJugador = ronda2[i].equals(nombreJugador);
                        color = casillaEsJugador ? (victoriaJugadorEnR2 ? colorVerde : colorRojo)
                                : (victoriaJugadorEnR2 ? colorRojo : colorVerde);
                    } else if (i == 2 || i == 3) {
                        color = ronda3[1] != null && ronda3[1].equals(ronda2[i]) ? colorVerde : colorRojo;
                    }
                } else {
                    color = colorGris;
                }

                dibujarCasilla(lienzo, posicionesRonda2[i][0], posicionesRonda2[i][1], textoCasilla, color);
            }

            // Ronda 3 (final)
            NodoResultado r3Nodo = (r2Nodo != null) ? r2Nodo.getSiguiente() : null;
            Invasion.ResultadoBatalla resR3 = (r3Nodo != null) ? r3Nodo.getResultado() : null;

            for (int i = 0; i < 2; i++) {
                String textoCasilla = (ronda3[i] != null) ? ronda3[i] : "–";
                Color color = colorGris;

                if (resR3 != null && ronda3[i] != null) {
                    boolean victoriaJugadorEnR3 = resR3 == Invasion.ResultadoBatalla.VICTORIA;
                    boolean casillaEsJugador = ronda3[i].equals(nombreJugador);
                    color = casillaEsJugador ? (victoriaJugadorEnR3 ? colorVerde : colorRojo)
                            : (victoriaJugadorEnR3 ? colorRojo : colorVerde);
                }

                dibujarCasilla(lienzo, posicionesRonda3[i][0], posicionesRonda3[i][1], textoCasilla, color);
            }

            // Casilla final en dorado
            String textoFinal = "Ganador: " + (ganadorFinal != null ? ganadorFinal : "–");
            dibujarCasilla(lienzo, posicionFinal[0], posicionFinal[1], textoFinal, colorDorado);
        }

        private void dibujarCasilla(Graphics lienzo, int posicionX, int posicionY, String textoCasilla, Color colorFondo) {
            if (textoCasilla == null) {
                textoCasilla = "–";
            }
            lienzo.setColor(colorFondo);
            lienzo.fillRoundRect(posicionX, posicionY, anchoCasilla, altoCasilla, 10, 10);

            lienzo.setColor(Color.DARK_GRAY);
            lienzo.drawRoundRect(posicionX, posicionY, anchoCasilla, altoCasilla, 10, 10);

            lienzo.setColor(Color.BLACK);
            lienzo.setFont(fuenteCasilla);
            FontMetrics medidas = lienzo.getFontMetrics();
            int textoX = posicionX + (anchoCasilla - medidas.stringWidth(textoCasilla)) / 2;
            int textoY = posicionY + (altoCasilla + medidas.getAscent()) / 2 - 6;
            lienzo.drawString(textoCasilla, textoX, textoY);
        }
    }
}
