package Formularios;

import batalla.RegistroBatalla;
import java.awt.*;
import javax.swing.*;

public class FrmDetalleBatalla extends JFrame {

    private RegistroBatalla registro;
    private JComboBox<Integer> cmbRondas;
    private JTextArea txtEventos;

    public FrmDetalleBatalla(RegistroBatalla registro) {
        this.registro = registro;
        setTitle("Detalle de la Batalla por Ronda");
        setSize(600, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        // Selector de rondas
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        topPanel.add(new JLabel("Seleccionar ronda:"));
        cmbRondas = new JComboBox<>();
        cmbRondas.addActionListener(e -> mostrarEventosDeRonda());
        topPanel.add(cmbRondas);
        add(topPanel, BorderLayout.NORTH);

        // Área de texto para eventos
        txtEventos = new JTextArea();
        txtEventos.setEditable(false);
        txtEventos.setFont(new Font("Tw Cen MT", Font.PLAIN, 16));
        txtEventos.setLineWrap(true);
        txtEventos.setWrapStyleWord(true);
        JScrollPane scroll = new JScrollPane(txtEventos);
        add(scroll, BorderLayout.CENTER);

        // Botón cerrar
        JButton btnCerrar = new JButton("Cerrar");
        btnCerrar.addActionListener(e -> dispose());
        JPanel bottomPanel = new JPanel();
        bottomPanel.add(btnCerrar);
        add(bottomPanel, BorderLayout.SOUTH);

        actualizarRegistro(); // inicializa al abrir
    }

    public void actualizarRegistro() {
        cmbRondas.removeAllItems();

        int[] rondasRegistradas = registro.obtenerRondasRegistradas();
        for (int i = 0; i < rondasRegistradas.length; i++) {
            cmbRondas.addItem(rondasRegistradas[i]);
        }

        if (cmbRondas.getItemCount() > 0) {
            cmbRondas.setSelectedIndex(cmbRondas.getItemCount() - 1);
            mostrarEventosDeRonda();
        } else {
            txtEventos.setText("No hay rondas registradas.");
        }
    }

    private void mostrarEventosDeRonda() {
        Integer rondaSeleccionada = (Integer) cmbRondas.getSelectedItem();
        if (rondaSeleccionada == null) {
            txtEventos.setText("No hay rondas seleccionadas.");
            return;
        }

        String[] eventos = registro.obtenerEventosDeRonda(rondaSeleccionada);
        if (eventos.length == 0) {
            txtEventos.setText("No hay eventos registrados en esta ronda.");
        } else {
            // Formatear con viñetas
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < eventos.length; i++) {
                if (i == 0) {
                    sb.append("• ").append(eventos[i]);
                } else {
                    sb.append("\n• ").append(eventos[i]);
                }
            }
            txtEventos.setText(sb.toString());
        }
    }
}
