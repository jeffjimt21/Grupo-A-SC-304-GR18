package Formularios;

import Invasion.claseControladora;
import javax.swing.*;

public class FrmResultado extends JFrame {

    private JLabel lblResultado;
    private JButton btnSalir;
    private JButton btnAccion;

    public FrmResultado(String resultado) {
        initComponents();

        lblResultado.setText(resultado);

        boolean torneoTerminado = claseControladora.getCantidadBatallas() >= 3;
        if ("VICTORIA".equals(resultado)) {
            if (torneoTerminado) {
                btnAccion.setText("Mostrar resultados");
                btnAccion.addActionListener(e -> {
                    // Aquí muestra un resumen final o vuelves al menú
                    FrmMostrarInvasion resumen = new FrmMostrarInvasion();
                    resumen.setVisible(true);
                    dispose();
                });
            } else {
                btnAccion.setText("Siguiente ronda");
                btnAccion.addActionListener(e -> {
                    FrmMostrarInvasion resumen = new FrmMostrarInvasion();
                    resumen.setVisible(true);
                    dispose();
                });
            }
        } else {
            btnAccion.setText("Volver al inicio");
            btnAccion.addActionListener(e -> {
                FrmInvasion inicio = new FrmInvasion(claseControladora.getNombreJugador());
                inicio.setVisible(true);
                dispose();
            });
        }

        btnSalir.addActionListener(e -> System.exit(0));
    }

    private void initComponents() {
        setTitle("Resultado de la Invasión");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        lblResultado = new JLabel("Resultado");
        lblResultado.setBounds(50, 50, 300, 40);
        lblResultado.setHorizontalAlignment(SwingConstants.CENTER);
        lblResultado.setFont(new java.awt.Font("Tw Cen MT", 1, 24));
        add(lblResultado);

        btnSalir = new JButton("Salir");
        btnSalir.setBounds(60, 150, 100, 40);
        add(btnSalir);

        btnAccion = new JButton("Acción");
        btnAccion.setBounds(200, 150, 150, 40);
        add(btnAccion);
    }
}
