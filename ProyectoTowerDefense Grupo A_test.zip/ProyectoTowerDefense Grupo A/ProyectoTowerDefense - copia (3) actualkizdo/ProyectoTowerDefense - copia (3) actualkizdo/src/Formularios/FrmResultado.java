package Formularios;

import javax.swing.*;

public class FrmResultado extends JFrame {

    private JLabel lblResultado;

    private FrmInvasion frmInvasion;
    private boolean ganoJugador;

    public FrmResultado(String resultado, boolean ganoJugador, FrmInvasion frmInvasion) {
        this.ganoJugador = ganoJugador;
        this.frmInvasion = frmInvasion;
        initComponents();
        lblResultado.setText(resultado);

        if (ganoJugador) {
            mostrarBracketYContinuar();
        }
    }

    private void initComponents() {
        setTitle("Resultado");
        setSize(400, 250);
        setLocationRelativeTo(null);
        setLayout(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        lblResultado = new JLabel("", SwingConstants.CENTER);
        lblResultado.setFont(new java.awt.Font("Tw Cen MT", 1, 24));
        lblResultado.setBounds(50, 80, 300, 40);
        add(lblResultado);
    }

    private void mostrarBracketYContinuar() {

        // Mostrar bracket
        FrmBracket bracket = new FrmBracket(
            frmInvasion,
            frmInvasion.getBatallasGanadas()
        );
        bracket.setVisible(true);

        // Timer de 5 segundos
        Timer timer = new Timer(5000, e -> {
            bracket.dispose();
            dispose();
            frmInvasion.iniciarSiguienteBatalla();
        });

        timer.setRepeats(false);
        timer.start();
    }
}