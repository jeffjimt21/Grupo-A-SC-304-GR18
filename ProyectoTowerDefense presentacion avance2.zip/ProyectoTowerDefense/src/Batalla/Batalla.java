package batalla;

import ColaBatalla.Cola;
import jugadores.Player;
import jugadores.CPU;
import tropas.Arquero;
import tropas.Caballero;
import tropas.Mago;
import tropas.Tropa;

public class Batalla {
    private int numero;
    private int ronda;
    private Player jugador;
    private CPU cpu;
    

    
    private Cola camino1Jugador = new Cola();
    private Cola camino2Jugador = new Cola();
    private Cola camino1CPU  = new Cola();
    private Cola camino2CPU  = new Cola();

    public Batalla(Player jugador, CPU cpu) {
        this.numero = 1;
        this.jugador = jugador;
        this.cpu = cpu;
        this.ronda = 1;
    }
    
    
    //Tambien se movio jugador
    
    public void prepararJugador(int caminos, Tropa tropa){
        
       

        if (caminos == 1) {
           camino1Jugador.encolar(tropa);
        } else {
          camino2Jugador.encolar(tropa);
    }
    }

        
        
        
    
    
    
   public Tropa seleccionarTropaAleatoria() {
    int decision = (int) (Math.random() * 3);  
    Tropa tropa;

    if (decision == 0) {
        tropa = new Arquero();
    } else if (decision == 1) {
        tropa = new Mago();
    } else {
        tropa = new Caballero();
    }

    
    System.out.println("CPU escogió: " + tropa.getTipo());

    return tropa;
}


    //Se movio aca, porque ahi toma directamente los caminos que se crean por aca
    
    
     public void prepararCPU() {
        int cantidad = Math.max(0, ronda); 
        int limiteCamino = (int)Math.floor(cantidad * 0.75);// no puede ser mayor al 75% de sus tropas y redondea
        if (limiteCamino < 1) //no puede ser decimal
            limiteCamino = cantidad;//rondas como 1

        int c1 = 0, c2 = 0;//contadores

        for (int i = 0; i < cantidad; i++) {
            Tropa tropa = seleccionarTropaAleatoria();
            boolean camino1 = Math.random() < 0.5;

            if (camino1 && c1 >= limiteCamino) camino1 = false; //si camino uno y contador son mayor que el limite entonces el uno no sera por el que sigue
            if (!camino1 && c2 >= limiteCamino) camino1 = true;//si es que en el camino dos hace eso, toma el 1

            if (camino1){
                System.out.println("CPU encoló " + tropa.getTipo() + " en camino 1");
                camino1CPU.encolar(tropa); c1++; 
            }
            else{ 
                System.out.println("CPU encoló " + tropa.getTipo() + " en camino 1");
                camino2CPU.encolar(tropa); c2++;
            }
        }
    }
     
     
 
    

public void Enfrentamiento() throws Exception {

    

   
    System.out.println("camino 1");

    if (!camino1Jugador.estaVacia() && !camino1CPU.estaVacia()) {

        Tropa j1 = camino1Jugador.frente();
        Tropa c1 = camino1CPU.frente();

       

        if (j1.getFortaleza().equals(c1.getTipo())) {

            System.out.println("ugador gana");
            System.out.println("Daño realizado: " + j1.getDanio());
            System.out.println("Vida CPU antes: " + cpu.getCastillo().getVida());

            camino1CPU.desencolar(); 
            Tropa atacante = camino1Jugador.desencolar();

            cpu.getCastillo().recibirDanio(atacante.getDanio());

           
        } 
        else if (c1.getFortaleza().equals(j1.getTipo())) {

            System.out.println("Cpu gana");
            System.out.println("Daño realizado: " + c1.getDanio());
            System.out.println("Vida Jugador antes: " + jugador.getCastillo().getVida());

            camino1Jugador.desencolar();
            Tropa atacante = camino1CPU.desencolar();

            jugador.getCastillo().recibirDanio(atacante.getDanio());

          
        } 
        else {
            System.out.println("Nadie hace daño");

            camino1Jugador.desencolar();
            camino1CPU.desencolar();
        }
    } 
    else if (!camino1Jugador.estaVacia() && camino1CPU.estaVacia()) {

        System.out.println("CPU no tiene tropas en Camino");

        Tropa atacante = camino1Jugador.desencolar();

        System.out.println("Tropa atacante: " + atacante.getTipo());
        System.out.println("Daño: " + atacante.getDanio());
        System.out.println("Vida CPU antes: " + cpu.getCastillo().getVida());

        cpu.getCastillo().recibirDanio(atacante.getDanio());

        
    } 
    else if (camino1Jugador.estaVacia() && !camino1CPU.estaVacia()) {

        System.out.println("Jugador no tiene tropas en Camino 1 ");

        Tropa atacante = camino1CPU.desencolar();

        System.out.println("Tropa atacante: " + atacante.getTipo());
        System.out.println("Daño: " + atacante.getDanio());
        System.out.println("Vida Jugador antes: " + jugador.getCastillo().getVida());

        jugador.getCastillo().recibirDanio(atacante.getDanio());

      
    }

    System.out.println("camino 2");

    if (!camino2Jugador.estaVacia() && !camino2CPU.estaVacia()) {

        Tropa j2 = camino2Jugador.frente();
        Tropa c2 = camino2CPU.frente();

      

        if (j2.getFortaleza().equals(c2.getTipo())) {

            System.out.println("Jugador GANA");
            System.out.println("Daño realizado: " + j2.getDanio());
            System.out.println("Vida CPU antes: " + cpu.getCastillo().getVida());

            camino2CPU.desencolar();
            Tropa atacante = camino2Jugador.desencolar();

            cpu.getCastillo().recibirDanio(atacante.getDanio());

            
        } 
        else if (c2.getFortaleza().equals(j2.getTipo())) {

            System.out.println("CPU GANA");
            System.out.println("Daño realizado: " + c2.getDanio());
            System.out.println("Vida Jugador antes: " + jugador.getCastillo().getVida());

            camino2Jugador.desencolar();
            Tropa atacante = camino2CPU.desencolar();

            jugador.getCastillo().recibirDanio(atacante.getDanio());

           
        } 
        else {

            System.out.println("Nadie hace daño");

            camino2Jugador.desencolar();
            camino2CPU.desencolar();
        }
    } 
    else if (!camino2Jugador.estaVacia() && camino2CPU.estaVacia()) {

        System.out.println("CPU no tiene tropas en Camino 2");

        Tropa atacante = camino2Jugador.desencolar();

        System.out.println("Tropa atacante: " + atacante.getTipo());
        System.out.println("Daño: " + atacante.getDanio());
        System.out.println("Vida CPU antes: " + cpu.getCastillo().getVida());

        cpu.getCastillo().recibirDanio(atacante.getDanio());

        
    } 
    else if (camino2Jugador.estaVacia() && !camino2CPU.estaVacia()) {

        System.out.println("Jugador no tiene tropas en Camino 2");

        Tropa atacante = camino2CPU.desencolar();

        System.out.println("Tropa atacante: " + atacante.getTipo());
        System.out.println("Daño: " + atacante.getDanio());
        System.out.println("Vida Jugador antes: " + jugador.getCastillo().getVida());

        jugador.getCastillo().recibirDanio(atacante.getDanio());

        
    }

    
}

   
   public boolean rondaTerminada() {
       
    return camino1Jugador.estaVacia() && camino2Jugador.estaVacia() &&camino1CPU.estaVacia() && camino2CPU.estaVacia();//devolver todo vacio
    
   }
   
   public void AumentarRonda(){
   
       ronda++;
       
   
   }
   
  


    public boolean batallaTerminada() {
        
    return jugador.getCastillo().getVida() <= 0 || cpu.getCastillo().getVida() <= 0;
    
    
    }
    
//La vida de cada castillo dicta quien gano
    public String resultadoBatalla() {
        
     if (jugador.getCastillo().getVida() <= 0)
         return "Derrota";
     
     if (cpu.getCastillo().getVida() <= 0)
         
        return "Victoria";
        return "En curso";
    }   
    
  
   


    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public int getRonda() {
        return ronda;
    }

    public void setRonda(int ronda) {
        this.ronda = ronda;
    }

    public Player getJugador() {
        return jugador;
    }

    public void setJugador(Player jugador) {
        this.jugador = jugador;
    }

    public CPU getCpu() {
        return cpu;
    }

    public void setCpu(CPU cpu) {
        this.cpu = cpu;
    }

    public Cola getCamino1Jugador() {
        return camino1Jugador;
    }

    public void setCamino1Jugador(Cola camino1Jugador) {
        this.camino1Jugador = camino1Jugador;
    }

    public Cola getCamino2Jugador() {
        return camino2Jugador;
    }

    public void setCamino2Jugador(Cola camino2Jugador) {
        this.camino2Jugador = camino2Jugador;
    }

    public Cola getCamino1CPU() {
        return camino1CPU;
    }

    public void setCamino1CPU(Cola camino1CPU) {
        this.camino1CPU = camino1CPU;
    }

    public Cola getCamino2CPU() {
        return camino2CPU;
    }

    public void setCamino2CPU(Cola camino2CPU) {
        this.camino2CPU = camino2CPU;
    }

 


     
    
    
}
    
     
     
     


   
   
    
    

