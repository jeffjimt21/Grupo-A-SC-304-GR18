package batalla;

import ColaBatalla.Cola;
import jugadores.Player;
import jugadores.CPU;
import tropas.Arquero;
import tropas.Caballero;
import tropas.Mago;
import tropas.Tropa;

public class Batalla {
    private int numero;
    private int ronda;
    private Player jugador;
    private CPU cpu;

    
    private Cola camino1Jugador = new Cola();
    private Cola camino2Jugador = new Cola();
    private Cola camino1CPU  = new Cola();
    private Cola camino2CPU  = new Cola();

    public Batalla(Player jugador, CPU cpu) {
        this.numero = 1;
        this.jugador = jugador;
        this.cpu = cpu;
        this.ronda = 1;
    }
    
    
    //Tambien se movio jugador
    
    public void prepararJugador(int caminos, Tropa tropa){
        
        int maximo = ronda+1;
        
        if (caminos==1) {
            
            for (int i = 0; i < maximo; i++) {
                
                camino1Jugador.encolar(tropa);
                
            }
           
        } else {
        
            for (int i = 0; i < maximo; i++) {
                
                camino2Jugador.encolar(tropa);
                
            }
        
        }
        
        
        
    
    }
    
    public Tropa seleccionarTropaAleatoria() {
        int decision = (int) (Math.random() * 3);  
      

        if (decision == 0) {
            return new Arquero();
        } else if (decision == 1) {
            return new Mago();
        } else if (decision==2) {
            return new Caballero();
        } else {
            return new Arquero();
        
        }

      
    }

    //Se movio aca, porque ahi toma directamente los caminos que se crean por aca
    
    
     public void prepararCPU() {
        int cantidad = Math.max(0, ronda); 
        int limiteCamino = (int)Math.floor(cantidad * 0.75);// no puede ser mayor al 75% de sus tropas y redondea
        if (limiteCamino < 1) //no puede ser decimal
            limiteCamino = cantidad;//rondas como 1

        int c1 = 0, c2 = 0;//contadores

        for (int i = 0; i < cantidad; i++) {
            Tropa tropa = seleccionarTropaAleatoria();
            boolean camino1 = Math.random() < 0.5;

            if (camino1 && c1 >= limiteCamino) camino1 = false; //si camino uno y contador son mayor que el limite entonces el uno no sera por el que sigue
            if (!camino1 && c2 >= limiteCamino) camino1 = true;//si es que en el camino dos hace eso, toma el 1

            if (camino1){
                camino1CPU.encolar(tropa); c1++; 
            }
            else{ 
                camino2CPU.encolar(tropa); c2++;
            }
        }
    }
     
     
   public void Enfrentamiento() throws Exception {
    

    //CAMINO 1
    if (!camino1Jugador.estaVacia() && !camino1CPU.estaVacia()) {//camino 1 no esta vacio
        Tropa j1 = camino1Jugador.frente();//frente camino 1, tropa de enfrente
        Tropa c1 = camino1CPU.frente();//frente camino 1, tropa de enfrente cpu

        

        if (j1.getFortaleza().equals(c1.getTipo())) {//fortaleza de jugador es igual al enemigo, por eso gana el jugador y la vida del castillo baja segun cuanto haga la tropa del jugador
            camino1CPU.desencolar(); // CPU pierde
            
             String mensaje = " Jugador gana en Camino 1";
            
             Tropa atacante = camino1Jugador.desencolar();//cumplio porque va pegar
             
             cpu.getCastillo().recibirDanio(atacante.getDanio());
             
        } 
        else if (c1.getFortaleza().equals(j1.getTipo())) {
            camino1Jugador.desencolar(); // Jugador pierde
            
             String mensaje = " CPU gana en Camino 1";
            
             Tropa atacante = camino1CPU.desencolar();
             
             jugador.getCastillo().recibirDanio(atacante.getDanio());
        } 
        else {
            
            camino1Jugador.desencolar();
            camino1CPU.desencolar();
            
            String mensaje = "️ Empate en Camino 1";
           
        }
    } 
    else if (!camino1Jugador.estaVacia() && camino1CPU.estaVacia()) {//cuando solo un camino esta solo
        // Jugador ataca castillo CPU
        
        Tropa atacante = camino1Jugador.desencolar();//se tiene que quitar esta tropa ya ataco
        
        cpu.getCastillo().recibirDanio(atacante.getDanio());
    
    } 
    
    //igual anterior a este
    else if (camino1Jugador.estaVacia() && !camino1CPU.estaVacia()) {
        // CPU ataca castillo jugador
        Tropa atacante = camino1CPU.desencolar();
        jugador.getCastillo().recibirDanio(atacante.getDanio());
        
    }


    //CAMINO 2, igual camino 1
    if (!camino2Jugador.estaVacia() && !camino2CPU.estaVacia()) {
        Tropa jugador2 = camino2Jugador.frente();
        Tropa cpu2 = camino2CPU.frente();

       

        if (jugador2.getFortaleza().equals(cpu2.getTipo())) {
            camino2CPU.desencolar();
            
            String mensaje=" Jugador gana en el Camino 2";
            
            
            Tropa atacante = camino2Jugador.desencolar();
            
            cpu.getCastillo().recibirDanio(atacante.getDanio());
        } 
        else if (cpu2.getFortaleza().equals(jugador2.getTipo())) {
            camino2Jugador.desencolar();
            
            String mensaje="CPU gana";
            
         
            
            Tropa atacante = camino2CPU.desencolar();
            
            jugador.getCastillo().recibirDanio(atacante.getDanio());
        } 
        else {
            camino2Jugador.desencolar();
            
            camino2CPU.desencolar();
            
           String mensaje="empate";
           
           
        }
    } 
    else if (!camino2Jugador.estaVacia() && camino2CPU.estaVacia()) {
        Tropa atacante = camino2Jugador.desencolar();
        
        cpu.getCastillo().recibirDanio(atacante.getDanio());
       
    } 
    else if (camino2Jugador.estaVacia() && !camino2CPU.estaVacia()) {
        Tropa atacante = camino2CPU.desencolar();
        
        jugador.getCastillo().recibirDanio(atacante.getDanio());
        
    }
    
    
    
    
    
    
}
   
   public boolean rondaTerminada() {
       
    return camino1Jugador.estaVacia() && camino2Jugador.estaVacia() &&camino1CPU.estaVacia() && camino2CPU.estaVacia();
    
   }
   
   //Esto puede ser despues der cada batalla
   private void limpiarCaminos() {
    camino1Jugador = new Cola();
    camino2Jugador = new Cola();
    camino1CPU = new Cola();
    camino2CPU = new Cola();
}


    public boolean batallaTerminada() {
        
    return jugador.getCastillo().getVida() <= 0 || cpu.getCastillo().getVida() <= 0;
    
    
    }
//La vida de cada castillo dicta quien gano
    public String resultadoBatalla() {
        
     if (jugador.getCastillo().getVida() <= 0)
         return "Derrota";
     
     if (cpu.getCastillo().getVida() <= 0)
         
        return "Victoria";
        return "En curso";
    }   

   
//Metodo main prueba generado, por pereza
   /* public static void main(String[] args) throws Exception {
    // === CREAR OBJETOS PRINCIPALES ===
    Player jugador = new Player("Lucas");
    CPU cpu = new CPU();
    Batalla batalla = new Batalla(jugador, cpu);

    System.out.println("⚔️ INICIO DE LA BATALLA ENTRE " + jugador.getNombre() + " Y CPU ⚔️");
    System.out.println("---------------------------------------------");
    System.out.println("🏰 Vida inicial del Jugador: " + jugador.getCastillo().getVida());
    System.out.println("🏰 Vida inicial del CPU: " + cpu.getCastillo().getVida());
    System.out.println("---------------------------------------------\n");

    // === PRIMERA RONDA ===
    batalla.prepararJugador(1, new Caballero());
    batalla.prepararCPU();

    // === BUCLE PRINCIPAL DE BATALLA ===
    while (!batalla.batallaTerminada()) {

        System.out.println("🔁 Ronda " + batalla.ronda + " - Enfrentamiento en curso...");
        batalla.Enfrentamiento();

        System.out.println("🏰 Vida Jugador: " + jugador.getCastillo().getVida());
        System.out.println("🏰 Vida CPU: " + cpu.getCastillo().getVida());
        System.out.println("---------------------------------------------");

        // Si todas las tropas se agotaron (colas vacías)
        if (batalla.rondaTerminada()) {
            System.out.println("✅ Fin de la ronda " + batalla.ronda);

            // Reiniciar caminos
            batalla.limpiarCaminos();

            // Pasar a la siguiente ronda
            batalla.ronda++;
            System.out.println("➡️ Preparando la ronda " + batalla.ronda + "...\n");

            // Nuevas tropas para siguiente ronda (puedes variar tipo o camino)
            if (batalla.ronda % 2 == 0) {
                batalla.prepararJugador(2, new Arquero());
            } else {
                batalla.prepararJugador(1, new Mago());
            }
            batalla.prepararCPU();
        }

        // Esperar un poco entre turnos (solo para ver animación en consola)
        Thread.sleep(800);
    }

    // === RESULTADO FINAL ===
    System.out.println("\n🏁 RESULTADO FINAL 🏁");
    System.out.println("Vida final del Jugador: " + jugador.getCastillo().getVida());
    System.out.println("Vida final del CPU: " + cpu.getCastillo().getVida());
    System.out.println("Estado de la batalla: " + batalla.resultadoBatalla());
    System.out.println("---------------------------------------------");
    System.out.println("🎮 Fin de la simulación.");
}*/

     
    
    
}
    
     
     
     


   
   
    
    

