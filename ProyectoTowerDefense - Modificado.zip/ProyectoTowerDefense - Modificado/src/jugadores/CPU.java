package jugadores;

import castillo.Castillo;

public class CPU {
    private Castillo castillo;

    public CPU() {
        this.castillo = new Castillo(); 
    }

    public Castillo getCastillo() {
        return castillo;
    }

    public void setCastillo(Castillo castillo) {
        this.castillo = castillo;
    }
}

    
    

