package Formularios;

import javax.swing.*;

public class FrmResultado extends JFrame {

    private JButton btnContinuar;
    private JButton btnSalir;
    private JLabel lblResultado;

    private FrmInvasion frmInvasion;
    private boolean ganoJugador;

    public FrmResultado(String resultado, boolean ganoJugador, FrmInvasion frmInvasion) {
        this.ganoJugador = ganoJugador;
        this.frmInvasion = frmInvasion;
        initComponents();
        lblResultado.setText(resultado);
    }

    private void initComponents() {
        setTitle("Resultado");
        setSize(400, 250);
        setLocationRelativeTo(null);
        setLayout(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        lblResultado = new JLabel("", SwingConstants.CENTER);
        lblResultado.setFont(new java.awt.Font("Tw Cen MT", 1, 24));
        lblResultado.setBounds(50, 30, 300, 40);
        add(lblResultado);

        btnContinuar = new JButton("Continuar");
        btnContinuar.setBounds(60, 120, 120, 40);
        btnContinuar.addActionListener(e -> {
            dispose();
            frmInvasion.iniciarSiguienteBatalla();
        });
        add(btnContinuar);

        btnSalir = new JButton("Salir");
        btnSalir.setBounds(220, 120, 100, 40);
        btnSalir.addActionListener(e -> {
            dispose();
            new FrmPrincipal().setVisible(true);
        });
        add(btnSalir);

        // Si perdió, no puede continuar
        if (!ganoJugador) {
            btnContinuar.setEnabled(false);
        }
    }
}