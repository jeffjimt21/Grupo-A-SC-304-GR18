package batalla;

public class RegistroBatalla {

    private NodoRonda cabeza;

    public RegistroBatalla() {
        this.cabeza = null;
    }

    public void registrarEvento(int ronda, String texto) {
        NodoRonda r = buscarRonda(ronda);
        if (r == null) {
            r = insertarRondaOrdenada(ronda);
        }
        r.agregarEvento(texto);
    }

    public int[] obtenerRondasRegistradas() {
        int count = 0;
        NodoRonda aux = cabeza;
        while (aux != null) {
            count++;
            aux = aux.sig;
        }

        int[] rondas = new int[count];
        aux = cabeza;
        int i = 0;
        while (aux != null) {
            rondas[i++] = aux.ronda;
            aux = aux.sig;
        }
        return rondas;
    }

    public String[] obtenerEventosDeRonda(int ronda) {
        NodoRonda r = buscarRonda(ronda);
        if (r == null) return new String[0];
        return r.obtenerEventos();
    }

    private NodoRonda buscarRonda(int ronda) {
        NodoRonda aux = cabeza;
        while (aux != null) {
            if (aux.ronda == ronda) return aux;
            aux = aux.sig;
        }
        return null;
    }

    private NodoRonda insertarRondaOrdenada(int ronda) {
        NodoRonda nuevo = new NodoRonda(ronda);

        if (cabeza == null || ronda < cabeza.ronda) {
            nuevo.sig = cabeza;
            cabeza = nuevo;
            return nuevo;
        }

        NodoRonda ant = cabeza;
        NodoRonda act = cabeza.sig;

        while (act != null && act.ronda < ronda) {
            ant = act;
            act = act.sig;
        }

        nuevo.sig = act;
        ant.sig = nuevo;
        return nuevo;
    }

    // ======= NODOS INTERNOS (sin java.util) =======

    private static class NodoRonda {
        int ronda;
        NodoRonda sig;

        NodoEvento evCabeza;
        NodoEvento evCola;
        int evSize;

        NodoRonda(int ronda) {
            this.ronda = ronda;
            this.sig = null;
            this.evCabeza = null;
            this.evCola = null;
            this.evSize = 0;
        }

        void agregarEvento(String texto) {
            NodoEvento n = new NodoEvento(texto);
            if (evCabeza == null) {
                evCabeza = n;
                evCola = n;
            } else {
                evCola.sig = n;
                evCola = n;
            }
            evSize++;
        }

        String[] obtenerEventos() {
            String[] arr = new String[evSize];
            NodoEvento aux = evCabeza;
            int i = 0;
            while (aux != null) {
                arr[i++] = aux.texto;
                aux = aux.sig;
            }
            return arr;
        }
    }

    private static class NodoEvento {
        String texto;
        NodoEvento sig;

        NodoEvento(String texto) {
            this.texto = texto;
            this.sig = null;
        }
    }
}