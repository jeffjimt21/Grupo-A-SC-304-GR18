package Formularios;

import javax.swing.*;

public class FrmResultado extends JFrame {

    private JLabel lblResultado;
    private JButton btnContinuar;
    private JButton btnSalir;

    private FrmInvasion frmInvasion;
    private boolean ganoJugador;

    public FrmResultado(String resultado, boolean ganoJugador, FrmInvasion frmInvasion) {
        this.ganoJugador = ganoJugador;
        this.frmInvasion = frmInvasion;
        initComponents();
        lblResultado.setText(resultado);

        // Si perdió: no hay continuar
        btnContinuar.setVisible(ganoJugador);

        // Si ya ganó 3: no hay continuar (es final)
        if (ganoJugador && frmInvasion.getBatallasGanadas() >= 3) {
            btnContinuar.setVisible(false);
        }
    }

    private void initComponents() {
        setTitle("Resultado");
        setSize(420, 260);
        setLocationRelativeTo(null);
        setLayout(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        lblResultado = new JLabel("", SwingConstants.CENTER);
        lblResultado.setFont(new java.awt.Font("Tw Cen MT", 1, 28));
        lblResultado.setBounds(50, 50, 320, 50);
        add(lblResultado);

        btnContinuar = new JButton("Continuar");
        btnContinuar.setBounds(80, 140, 120, 40);
        btnContinuar.addActionListener(e -> mostrarBracketYContinuar());
        add(btnContinuar);

        btnSalir = new JButton("Salir");
        btnSalir.setBounds(220, 140, 120, 40);
        btnSalir.addActionListener(e -> salir());
        add(btnSalir);
    }

    private void mostrarBracketYContinuar() {
        // Ocultar para que no le den doble click
        btnContinuar.setEnabled(false);
        btnSalir.setEnabled(false);

        FrmBracket bracket = new FrmBracket(frmInvasion, frmInvasion.getBatallasGanadas());
        bracket.setVisible(true);

        Timer timer = new Timer(5000, e -> {
            bracket.dispose();
            dispose();

            // Si ya ganó 3, termina todo
            if (frmInvasion.getBatallasGanadas() >= 3) {
                FrmPrincipal p = new FrmPrincipal();
                p.setVisible(true);
                frmInvasion.dispose();
                return;
            }

            frmInvasion.iniciarSiguienteBatalla();
        });

        timer.setRepeats(false);
        timer.start();
    }

    private void salir() {
        dispose();

        // Si perdió o si decidió salir, regresar al principal
        FrmPrincipal p = new FrmPrincipal();
        p.setVisible(true);

        if (frmInvasion != null) {
            frmInvasion.dispose();
        }
    }
}
