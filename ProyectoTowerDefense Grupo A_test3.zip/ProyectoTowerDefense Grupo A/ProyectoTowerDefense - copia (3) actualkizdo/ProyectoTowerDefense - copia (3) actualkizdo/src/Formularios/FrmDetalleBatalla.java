package Formularios;

import batalla.RegistroBatalla;
import java.awt.*;
import javax.swing.*;

public class FrmDetalleBatalla extends JFrame {

    private RegistroBatalla registro;
    private JComboBox<Integer> cmbRondas;
    private JTextArea txtEventos;

    public FrmDetalleBatalla(RegistroBatalla registro) {
        this.registro = registro;
        setTitle("Detalle de la Batalla por Ronda");
        setSize(600, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        topPanel.add(new JLabel("Seleccionar ronda:"));
        cmbRondas = new JComboBox<>();
        cmbRondas.addActionListener(e -> mostrarEventosDeRonda());
        topPanel.add(cmbRondas);
        add(topPanel, BorderLayout.NORTH);

        txtEventos = new JTextArea();
        txtEventos.setEditable(false);
        txtEventos.setFont(new Font("Tw Cen MT", Font.PLAIN, 16));
        txtEventos.setLineWrap(true);
        txtEventos.setWrapStyleWord(true);
        add(new JScrollPane(txtEventos), BorderLayout.CENTER);

        JButton btnCerrar = new JButton("Cerrar");
        btnCerrar.addActionListener(e -> dispose());
        JPanel bottomPanel = new JPanel();
        bottomPanel.add(btnCerrar);
        add(bottomPanel, BorderLayout.SOUTH);

        actualizarRegistro();
    }

    public void actualizarRegistro() {
        cmbRondas.removeAllItems();

        int[] rondas = registro.obtenerRondasRegistradas();
        for (int i = 0; i < rondas.length; i++) {
            cmbRondas.addItem(rondas[i]);
        }

        if (cmbRondas.getItemCount() > 0) {
            cmbRondas.setSelectedIndex(cmbRondas.getItemCount() - 1);
            mostrarEventosDeRonda();
        } else {
            txtEventos.setText("No hay rondas registradas.");
        }
    }

    private void mostrarEventosDeRonda() {
        Integer rondaSeleccionada = (Integer) cmbRondas.getSelectedItem();
        if (rondaSeleccionada == null) {
            txtEventos.setText("No hay rondas seleccionadas.");
            return;
        }

        String[] eventos = registro.obtenerEventosDeRonda(rondaSeleccionada);
        if (eventos.length == 0) {
            txtEventos.setText("No hay eventos registrados en esta ronda.");
            return;
        }

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < eventos.length; i++) {
            sb.append("• ").append(eventos[i]).append("\n");
        }
        txtEventos.setText(sb.toString());
    }
}