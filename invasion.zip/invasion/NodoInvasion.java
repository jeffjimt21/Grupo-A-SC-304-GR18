/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto.invasion;

/**
 *
 * @author lucas
 */


import batalla.Batalla;

public class NodoInvasion {

    private Batalla dato;
    private NodoInvasion siguiente;

    public NodoInvasion(Batalla dato) {
        this.dato = dato;
        this.siguiente = null;
    }

    public Batalla getDato() {
        return dato;
    }

    public void setDato(Batalla dato) {
        this.dato = dato;
    }

    public NodoInvasion getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(NodoInvasion siguiente) {
        this.siguiente = siguiente;
    }
}
