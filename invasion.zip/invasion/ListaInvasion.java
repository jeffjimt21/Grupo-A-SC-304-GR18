/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto.invasion;

/**
 *
 * @author lucas
 */


import batalla.Batalla;

public class ListaInvasion {
    
    private NodoInvasion cabeza;
    private NodoInvasion actual;

    public ListaInvasion() {
        this.cabeza = null;
        this.actual = null;
    }

   
    public void InsertarFinal(Batalla batalla) {

        NodoInvasion nuevo = new NodoInvasion(batalla);

        if (cabeza == null) {
            cabeza = nuevo;
            actual = cabeza;
            return;
        }

        NodoInvasion actual = cabeza;

        while (actual.getSiguiente() != null) {
            actual = actual.getSiguiente();
        }

        actual.setSiguiente(nuevo);
    }


   
    public void avanzar() {
        if (actual != null) {
            actual = actual.getSiguiente();
        }
    }

    public Batalla getBatallaActual() {
        if (actual == null) return null;
        return actual.getDato();
    }

    public boolean invasionTerminada() {
        return actual == null;
    }


    // Buscar según número de batalla
    public boolean buscar(int numero) {
        NodoInvasion actual = cabeza;

        while (actual != null) {
            if (actual.getDato().getNumero() == numero)
                return true;

            actual = actual.getSiguiente();
        }

        return false;
    }

   
    public void recorrer() {
        NodoInvasion actual = cabeza;

        while (actual != null) {
            System.out.println("Batalla #" + actual.getDato().getNumero());
            actual = actual.getSiguiente();
        }

        System.out.println("NULL");
    }

}
