/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package arboles;

/**
 *
 * @author lucas
 */
 import batalla.Batalla;


public class NodoBatalla {
    

public class NodoBatalla {
    private Batalla dato;
    private NodoBatalla izquierda, derecha;

    public NodoBatalla(Batalla dato) {
        this.dato = dato;
        this.izquierda = null;
        this.derecha = null;
    }

    public Batalla getDato() {
        return dato;
    }

    public void setDato(Batalla dato) {
        this.dato = dato;
    }

    public NodoBatalla getIzquierda() {
        return izquierda;
    }

    public void setIzquierda(NodoBatalla izquierda) {
        this.izquierda = izquierda;
    }

    public NodoBatalla getDerecha() {
        return derecha;
    }

    public void setDerecha(NodoBatalla derecha) {
        this.derecha = derecha;
    }
}
}
