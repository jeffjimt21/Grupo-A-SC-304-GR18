/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package arboles;

/**
 *
 * @author lucas
 */
import batalla.Batalla;

public class ArbolBatalla {




    private NodoBatalla raiz;

    public ArbolBatalla() {
        this.raiz = null;
    }

    public NodoBatalla getRaiz() {
        return raiz;
    }

    public void insertar(Batalla batalla) {
        raiz = insertarRec(raiz, batalla);
    }

    private NodoBatalla insertarRec(NodoBatalla raiz, Batalla batalla) {

        if (raiz == null) {
            return new NodoBatalla(batalla);
        }

        // Comparamos por numero de batalla
        if (batalla.getNumero() < raiz.getDato().getNumero()) {
            raiz.setIzquierda(insertarRec(raiz.getIzquierda(), batalla));
        } 
        else if (batalla.getNumero() > raiz.getDato().getNumero()) {
            raiz.setDerecha(insertarRec(raiz.getDerecha(), batalla));
        }

        return raiz;
    }


    
}

